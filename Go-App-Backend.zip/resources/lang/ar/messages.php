<?php
return
[
  "New Admin has been added successfully !" =>"تمت إضافه مشرف جديد بنجاح !",
  "New Trader has been added successfully !" =>"تمت إضافه تاجر جديد بنجاح !",
  "New Factory has been added successfully !" =>"تمت إضافه مصنع جديد بنجاح !",
  "New Category has been added successfully !" =>"تمت إضافه فئه جديده بنجاح !",
  "New Product has been added successfully !" =>"تمت إضافه منتج جديد بنجاح !",
  "New Product Tag has been added successfully !" =>"تمت إضافه عنوان منتج بنجاح !",
  "admin's info has been updated successfully" => "تمت تعديل بيانات المشرف بنجاح !",
  "category's info has been updated successfully" => "تمت تعديل بيانات الفئه بنجاح !",
  "factory's info has been updated successfully" => "تمت تعديل بيانات المصنع بنجاح !",
  "product's info has been updated successfully" => "تمت تعديل بيانات المنتج بنجاح !",
  "product tag's info has been updated successfully" => "تمت تعديل بيانات عنوان المنتج بنجاح !",
  "trader's info has been updated successfully" => "تمت تعديل بيانات التاجر بنجاح !",
];

?>
