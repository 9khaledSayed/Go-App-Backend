<!--begin::Footer-->
<div class="footer bg-white py-4 d-flex flex-column mt-10 noprint" style="position:fixed;bottom: 0;width:100%;"  >
    <!--begin::Container-->

        <div class="text-dark order-2 order-md-1 m-auto">
            <h4><a href="https://webstdy.com/ar" target="_blank" class="text-dark-75 text-hover-primary">Go-App</a></h4>
            <span class="text-muted font-weight-bold">2021©</span>
        </div>
        <!--end::Copyright-->

</div>
<!--end::Footer-->
<?php /**PATH /home/khaledsayed/gitHub/Go-App/GO-App-Backend/resources/views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>