<?php $__env->startPush('styles'); ?>
    <style>
        .radio-inline .radio span {
            margin-right: 0.75rem;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Card-->
            <div class="card card-custom">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-custom example example-compact">
                            <div class="card-header">
                                <h2 class="card-title">عرض تفاصيل الخاصية</h2>
                            </div>
                            <!--begin::Form-->
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="mb-2">
                                        <div class="form-group row">
                                            <div class="col-lg-12">
                                                <label>* الأســـم :</label>
                                                <input type="text" name="name" class="form-control" disabled value="<?php echo e($attribute->name); ?>" />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-lg-12">
                                                <label>* النوع :</label>
                                                <div class="radio-inline" style="width: fit-content; margin: auto">
                                                    <label class="radio radio-primary">
                                                        <input type="radio" name="type" disabled <?php if(($attribute->type) == 'number'): ?> checked <?php endif; ?> value="number" /> رقم
                                                        <span></span>
                                                    </label>
                                                    <label class="radio radio-danger">
                                                        <input type="radio" name="type" disabled value="size" <?php if(($attribute->type) == 'size'): ?> checked <?php endif; ?> id="size"/>مقاس
                                                        <span></span>
                                                    </label>
                                                    <label class="radio radio-warning">
                                                        <input type="radio" name="type" disabled value="list" <?php if(($attribute->type) == 'list'): ?> checked <?php endif; ?> id="list"/>خيارات متعددة
                                                        <span></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row" id="valuesDiv" style="display: none">
                                            <label class="col-form-label text-right col-lg-3 col-sm-12">Values</label>
                                            <div class="col-lg-6 col-md-9 col-sm-12">
                                                <input id="values" class="form-control tagify" disabled name='value' value='<?php echo e($attribute->value); ?>' />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="row">
                                    <div class="col-lg-12 text-center">
                                        <a href="<?php echo e(route('dashboard.attributes.index')); ?>" class="btn btn-light-primary font-weight-bold">إلـغـاء</a>
                                    </div>
                                </div>
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Card-->
                    </div>
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/attribute_form.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/khaledsayed/gitHub/Go-App/GO-App-Backend/resources/views/dashboard/attributes/show.blade.php ENDPATH**/ ?>