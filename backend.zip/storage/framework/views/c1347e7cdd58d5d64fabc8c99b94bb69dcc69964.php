<<<<<<< HEAD
<!--begin::Aside-->
<div class="aside aside-left aside-fixed d-flex flex-column flex-row-auto noprint" id="kt_aside">
    <li class="menu-item menu-item-active mt-10 mb-10 text-center" aria-haspopup="true">

        <a href="<?php echo e(route('dashboard.index')); ?>">
            <img alt="Logo"  src="<?php echo e(asset('assets/logo.png')); ?>" style="height:100px;width:90px;" />
        </a>

    </li>
    <!--begin::Aside Menu-->
    <div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
        <!--begin::Menu Container-->
        <div id="kt_aside_menu" class="aside-menu my-4" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500">
            <!--begin::Menu Nav-->
            <ul class="menu-nav">



                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="javascript:;" class="menu-link menu-toggle">
										<span class="svg-icon menu-icon">
										<span class="svg-icon menu-icon">
											<i class="flaticon2-protected"></i>
										</span>
										</span>
                        <span class="menu-text">المشرفون</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="menu-submenu">
                        <i class="menu-arrow"></i>
                        <ul class="menu-subnav">
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.admins.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">قائمة المشرفون</span>
                                </a>
                            </li>
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.admins.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">اضافة المشرفون</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>


                <li class="menu-item menu-item" aria-haspopup="true">
                    <a href="<?php echo e(route('dashboard.users.index')); ?>" class="menu-link">
                            <span class="svg-icon menu-icon">
                                <span class="svg-icon menu-icon">
                                    <i class="flaticon2-user-outline-symbol"></i>
                                </span>
                            </span>
                        <span class="menu-text">المستخدمين</span>
                    </a>
                </li>

                <li class="menu-item menu-item" aria-haspopup="true">
                    <a href="<?php echo e(route('dashboard.providers.index')); ?>" class="menu-link">
                            <span class="svg-icon menu-icon">
                                <span class="svg-icon menu-icon">
                                    <i class="flaticon2-user-1"></i>
                                </span>
                            </span>
                        <span class="menu-text">مزودي الخدمة</span>
                    </a>
                </li>

                <li class="menu-item menu-item" aria-haspopup="true">
                    <a href="<?php echo e(route('dashboard.orders.index')); ?>" class="menu-link">
                            <span class="svg-icon menu-icon">
                                <span class="svg-icon menu-icon">
                                    <i class="flaticon2-box"></i>
                                </span>
                            </span>
                        <span class="menu-text">الطلبات</span>
                    </a>
                </li>

                <li class="menu-item menu-item" aria-haspopup="true">
                    <a href="<?php echo e(route('dashboard.offers.index')); ?>" class="menu-link">
                            <span class="svg-icon menu-icon">
                                <span class="svg-icon menu-icon">
                                    <i class="flaticon2-layers-2"></i>
                                </span>
                            </span>
                        <span class="menu-text">العروض</span>
                    </a>
                </li>

                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="javascript:;" class="menu-link menu-toggle">
										<span class="svg-icon menu-icon">
										<span class="svg-icon menu-icon">
											<i class="flaticon2-box-1"></i>
										</span>
										</span>
                        <span class="menu-text">الخدمات</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="menu-submenu">
                        <i class="menu-arrow"></i>
                        <ul class="menu-subnav">
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.services.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">قائمة الخدمات</span>
                                </a>
                            </li>
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.services.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">اضافة خدمة جديدة</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="javascript:;" class="menu-link menu-toggle">
										<span class="svg-icon menu-icon">
										<span class="svg-icon menu-icon">
											<i class="fas fa-square"></i>
										</span>
										</span>
                        <span class="menu-text">الفئات</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="menu-submenu">
                        <i class="menu-arrow"></i>
                        <ul class="menu-subnav">
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.categories.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">قائمة الفئات</span>
                                </a>
                            </li>
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.categories.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">اضافة فئة جديدة</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="javascript:;" class="menu-link menu-toggle">
										<span class="svg-icon menu-icon">
										<span class="svg-icon menu-icon">
											<i class="flaticon2-layers"></i>
										</span>
										</span>
                        <span class="menu-text">الخصائص</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="menu-submenu">
                        <i class="menu-arrow"></i>
                        <ul class="menu-subnav">
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.attributes.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">قائمة الخصائص</span>
                                </a>
                            </li>
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.attributes.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">اضافة خاصية جديدة</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>


                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="javascript:;" class="menu-link menu-toggle">
										<span class="svg-icon menu-icon">
										<span class="svg-icon menu-icon">
											<i class="fa fa-credit-card"></i>
										</span>
										</span>
                        <span class="menu-text">طرق الدفع</span>
                        <i class="menu-arrow"></i>
                    </a>
                    <div class="menu-submenu">
                        <i class="menu-arrow"></i>
                        <ul class="menu-subnav">
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.payment-methods.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">قائمة طرق الدفع</span>
                                </a>
                            </li>
                            <li class="menu-item" aria-haspopup="true">
                                <a href="<?php echo e(route('dashboard.payment-methods.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text">اضافة طريقه دفع جديدة</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a href="<?php echo e(route('dashboard.settings.general')); ?>" class="menu-link menu-toggle">
                	<span class="svg-icon menu-icon">
                        <span class="svg-icon menu-icon">
                            <i class="flaticon2-settings"></i>
                        </span>
                    </span>
                        <span class="menu-text">الاعدادات</span>
                    </a>
                </li>

                <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                    <a onclick="document.getElementById('logout-form').submit();" href="javascript:" class="menu-link menu-toggle">
                	<span class="svg-icon menu-icon">
                        <span class="svg-icon menu-icon">
                            <i class="fas fa-sign-out-alt"></i>
                        </span>
                    </span>
                        <span class="menu-text">تسجيل الخروج</span>
                        <i class="menu-arrow"></i>
                    </a>
                </li>

                <form id="logout-form" action="<?php echo e(route('dashboard.logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>


            </ul>
            <!--end::Menu Nav-->
        </div>
        <!--end::Menu Container-->
    </div>
    <!--end::Aside Menu-->
</div>
<!--end::Aside-->

<?php /**PATH /home/khaledsayed/gitHub/Go-App/Go-App-Backend/resources/views/dashboard/layouts/aside.blade.php ENDPATH**/ ?>