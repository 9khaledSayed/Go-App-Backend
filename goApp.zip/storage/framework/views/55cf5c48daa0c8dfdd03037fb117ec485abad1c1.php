<?php $__env->startSection('title','المشرفون'); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">

            <!--begin::Card-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-custom example example-compact">
                        <div class="card-header">
                            <h2 class="card-title">إضـافة مشرف جـديد</h2>
                        </div>
                        <!--begin::Form-->
                        <form class="form" id="kt_form" action="<?php echo e(route('dashboard.admins.store')); ?>" method = "POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <?php echo $__env->make('dashboard.layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="mb-3">
                                    <div class="mb-2">
                                        <div class="form-group row">
                                            <div class="col-lg-6">
                                                <label>* الأســـم :</label>
                                                <input type="text" name="name" class="form-control" placeholder="أدخل اسم المشرف"  value="<?php echo e(old('name')); ?>" />
                                                <?php if($errors->has('name')): ?>
                                                    <div>
                                                        <p class="invalid-input"><?php echo e($errors->first('name')); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-lg-6">
                                                <label>* البريد الألكتروني :</label>
                                                <input type="email" name="email" class="form-control" placeholder="أدخل البريد الألكتروني"  value="<?php echo e(old('email')); ?>" />
                                                <?php if($errors->has('email')): ?>
                                                    <div>
                                                        <p class="invalid-input"><?php echo e($errors->first('email')); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-lg-6">
                                                <label>* كلمه المرور :</label>
                                                <input type="password" name="password" class="form-control" placeholder="أدخل كلمــه المرور" value="<?php echo e(old('password')); ?>" />
                                                <?php if($errors->has('password')): ?>
                                                    <div>
                                                        <p class="invalid-input"><?php echo e($errors->first('password')); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-lg-6">
                                                <label>* تأكيد كلمه المرور :</label>
                                                <input type="password" name="password_confirmation" class="form-control"  placeholder="أدخل كلمــه المرور مره اخري"  value="<?php echo e(old('password_confirmation')); ?>" />
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <div>
                                                        <p class="invalid-input"><?php echo e($errors->first('password_confirmation')); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="row">
                                    <div class="col-lg-12 text-center">
                                        <button type="reset" class="btn btn-light-primary font-weight-bold">إلـغـاء</button>
                                        <button type="submit" class="btn btn-primary font-weight-bold mr-2">تـأكيـد</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!--end::Form-->
                    </div>
                    <!--end::Card-->
                </div>
            </div>
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $('#kt_select_roles').select2({
            placeholder: "اختر",
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/khaledsayed/gitHub/Go-App/Go-App-Backend/resources/views/dashboard/admins/create.blade.php ENDPATH**/ ?>